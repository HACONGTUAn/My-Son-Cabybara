using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CapybaraMain
{
    public class BaseID : MonoBehaviour
    {
        public int id;
        public List<Item> items;
    }

}