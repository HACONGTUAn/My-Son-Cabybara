using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace Merge
{
    public interface IDamage
    {
        void TakeDamage(int damage);
    }
}