using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Merge
{
    public enum FruitType
    {
        Size1 = 0,
        Size2 = 1,
        Size3 = 2,
        Size4 = 3,
        Size5 = 4,
        Size6 = 5,
        Size7 = 6,
        Size8 = 7,
        Size9 = 8,
        Size10 = 9,
        Size11 = 10,

    }
}
