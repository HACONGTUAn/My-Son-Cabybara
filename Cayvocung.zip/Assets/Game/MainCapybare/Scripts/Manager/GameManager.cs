using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Capybara
{
    public class GameManager : Singleton<GameManager>
    {
        public Follow followChapter;
    }
}
