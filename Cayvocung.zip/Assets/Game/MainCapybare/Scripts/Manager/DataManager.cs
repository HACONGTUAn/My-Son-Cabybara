using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Capybara
{
    public class DataManager : Singleton<DataManager>
    {
        
    }
}
